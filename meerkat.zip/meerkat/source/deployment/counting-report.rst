Counting Report 如何开启
=========================

.. toctree::
   :titlesonly:

By `William Wu`_

.. contents:: Sections:
  :local:
  :depth: 2

开始使用之前
----------------
用户行为收集软件


摄像机配置Counting Report

.. image:: _static/CR/config-1.png


.. image:: _static/CR/config-2.png